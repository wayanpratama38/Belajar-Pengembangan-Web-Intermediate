document.addEventListener('DOMContentLoaded', async () => {
  console.log('Hello, world!');
});

window.addEventListener('hashchange', async () => {
  console.log('Hash changed!');
});
